﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CCEligibilityChecker.Models
{
    public class Customer
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [DisplayName("Date of Birth")]
        [Required]        
        [DataType(DataType.Date)]
        public DateTime DoB { get; set; }
        [Required]
        public int Income { get; set; }
        public string Eligibility { get; set; }
    }
}
