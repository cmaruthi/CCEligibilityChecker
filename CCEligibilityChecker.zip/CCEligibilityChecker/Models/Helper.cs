﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CCEligibilityChecker.Models
{
    public  static class Helper
    {

        public static string GetEligibility(DateTime dob,int income)

        {
            string value = null;
            int age = CalculateAge(dob);
            if (age < 18)
            {
                value= "not Eligible";
            }
            else if (age >= 18 && income > 30000)
            {
                value = "Barclays";
            }
            else if (age >= 18 && income <= 30000)
            {
                value = "Vanquis";
            }


            return value;
        }

        public static int GetId(DateTime dob, int income)

        {
            int value = 0;
            int age = CalculateAge(dob);
            if (age < 18)
            {
                value = 0;
            }
            else if (age >= 18 && income > 30000)
            {
                value = 1;
            }
            else if (age >= 18 && income <= 30000)
            {
                value = 2;
            }


            return value;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="birthDay"></param>
        /// <returns></returns>
        private static int CalculateAge(DateTime birthDay)
        {
            int years = DateTime.Now.Year - birthDay.Year;

            if ((birthDay.Month > DateTime.Now.Month) || (birthDay.Month == DateTime.Now.Month && birthDay.Day > DateTime.Now.Day))
                years--;

            return years;
        }
    }
}
