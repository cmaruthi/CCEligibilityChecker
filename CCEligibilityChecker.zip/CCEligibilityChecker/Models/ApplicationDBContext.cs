﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CCEligibilityChecker.Models
{
    public class ApplicationDBContext:DbContext
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="options">This Paramater is request for Dependency Injection</param>
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) :base(options)
        {

        }
        /// <summary>
        /// Ent
        /// </summary>
        public DbSet<Customer> Customer { get; set; }
        public DbSet<CardDetails> CardDetails { get; set; }
    }
}
