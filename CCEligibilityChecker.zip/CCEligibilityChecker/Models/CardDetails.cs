﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using System.ComponentModel.DataAnnotations;
namespace CCEligibilityChecker.Models
{
    public class CardDetails
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string BankName { get; set; }
        [Required]
        public int MinAge { get; set; }
        [Required]
        public int MinIncome { get; set; }
        [Required]
        public float APR { get; set; }
        [Required]
        public string Image { get; set; }

    }
}
