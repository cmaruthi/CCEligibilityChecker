﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CCEligibilityChecker.Migrations
{
    public partial class AddCustomerT : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Eligibility",
                table: "Customer",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Eligibility",
                table: "Customer");
        }
    }
}
