﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CCEligibilityChecker.Migrations
{
    public partial class cceligibility : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
