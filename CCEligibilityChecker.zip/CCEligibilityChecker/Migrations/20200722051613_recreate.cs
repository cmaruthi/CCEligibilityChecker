﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CCEligibilityChecker.Migrations
{
    public partial class recreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
